package com.scsp.model;

public class UserUpdatesModel 
{
  private String email;
  private String updates;
  private String url;
  public String getTechname() {
    return techname;
  }
  public void setTechname(String techname) {
    this.techname = techname;
  }
  private String techname;

  public String getEmail() {
    return email;
  }
  public void setEmail(String email) {
    this.email = email;
  }
  public String getUpdates() {
    return updates;
  }
  public void setUpdates(String updates) {
    this.updates = updates;
  }
  public String getURL() {
    return url;
  }
  public void setURL(String url) {
    this.url = url;
  }
 

}
